﻿//
function
scbg(objRef, state)
{
	objRef.style.backgroundColor = (1 == state) ? '#FEE24D' : '#F6F6F6';

	return;
}
//