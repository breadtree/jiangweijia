﻿document.write("<table width=768 border=0 cellspacing=0 cellpadding=0 align=center height=62>");
document.write("  <tr bgcolor=225EA7> ");
document.write("    <td width=10></td>");
document.write("    <td height=18 width=376><img src=http://211.95.129.162/images/chinaunicomlogo_sc_blue.jpg width=376 height=53></td>");
document.write("    <td height=18 align=right><a href=http://211.95.129.162/index_english.jsp class=english><font color=FFFB02><b>English</b></font></a></td>");
document.write("    <td height=18 width=22>&nbsp;</td>");
document.write("  </tr>");
document.write("</table>");